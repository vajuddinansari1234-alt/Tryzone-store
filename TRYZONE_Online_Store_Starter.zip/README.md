# TRYZONE ecommerce starter

## Included
- Responsive streetwear storefront and product categories
- Product-size selection, cart, shipping calculation
- COD order endpoint
- Razorpay order creation + server-side signature verification scaffold
- Simple bearer-token-protected order listing endpoint

## Run locally
1. Install Node.js 18+.
2. Copy `.env.example` to `.env`.
3. Run `npm install`.
4. Run `npm start`.
5. Open http://localhost:3000

## Important before accepting real orders
This is a deployable starter, **not yet a production-ready live store**.
- Add real product photos, final prices, size charts and stock.
- Add a persistent database (orders are currently held in memory and disappear when the server restarts).
- Configure Razorpay test keys, test payments, then obtain live keys after merchant onboarding/KYC.
- Add an ADMIN_TOKEN to `.env` before using `/api/admin/orders`.
- Configure HTTPS, domain, privacy policy, terms, shipping/returns policy, support email/phone.
- Add verified payment webhooks, inventory reservation/decrement, order emails/SMS, rate limiting, logging, backups and admin authentication before launch.
- Do not share `.env` or Razorpay secret keys. Never put secret keys in browser code.
- COD endpoint currently records order in the running server process only; persistent DB is required for reliable order management.

## Environment
`BASE_URL`, `RAZORPAY_KEY_ID`, `RAZORPAY_KEY_SECRET`, `ADMIN_TOKEN`, `RAZORPAY_WEBHOOK_SECRET`.

The browser will automatically offer COD. Online payment remains disabled until valid Razorpay keys are configured.
