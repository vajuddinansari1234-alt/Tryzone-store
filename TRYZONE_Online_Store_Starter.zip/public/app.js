const $=s=>document.querySelector(s), money=n=>"₹"+Number(n).toLocaleString("en-IN");
let products=[],cart=[],config={onlinePaymentsEnabled:false,shippingFreeAbove:999,shippingFee:79};
async function init(){
 try{const [p,c]=await Promise.all([fetch("/api/products"),fetch("/api/config")]);products=await p.json();config=await c.json();}catch(e){toast("Could not load store. Please refresh.");return}
 renderProducts();
}
function renderProducts(filter="All"){
 const list=products.filter(p=>filter==="All"||p.category===filter);
 $("#productCount").textContent=list.length+" PRODUCTS";
 $("#products").innerHTML=list.map((p,i)=>`<article class="product"><div class="product-art"><span class="garment">${p.category==="Hoodies"?"♧":p.category==="Bottoms"?"▤":"Ｔ"}</span></div><div class="product-info"><h3>${p.name}</h3><p>${p.description}</p><div class="price">${money(p.price)}</div><button class="add" data-id="${p.id}">SELECT SIZE · ADD TO BAG</button></div></article>`).join("");
 document.querySelectorAll("[data-id]").forEach(b=>b.onclick=()=>selectSize(b.dataset.id));
}
document.querySelectorAll("[data-filter]").forEach(b=>b.onclick=()=>{document.querySelectorAll("[data-filter]").forEach(x=>x.classList.remove("active"));b.classList.add("active");renderProducts(b.dataset.filter)});
function selectSize(id){
 const p=products.find(x=>x.id===id),size=prompt("Choose size: "+p.sizes.join(", "));
 if(!size)return;const s=size.trim().toUpperCase();if(!p.sizes.includes(s)){toast("Please enter one of the listed sizes.");return}
 const found=cart.find(x=>x.productId===id&&x.size===s);if(found)found.quantity++;else cart.push({productId:id,size:s,quantity:1});renderCart();toast("Added to your bag.");
}
function totals(){let subtotal=cart.reduce((n,x)=>n+products.find(p=>p.id===x.productId).price*x.quantity,0);let shipping=subtotal===0||subtotal>=config.shippingFreeAbove?0:config.shippingFee;return{subtotal,shipping,total:subtotal+shipping}}
function renderCart(){
 $("#cartCount").textContent=cart.reduce((n,x)=>n+x.quantity,0);
 $("#cartItems").innerHTML=cart.length?cart.map((x,i)=>{let p=products.find(p=>p.id===x.productId);return `<div class="cart-line"><div><b>${p.name}</b><small>Size ${x.size} · ${money(p.price)} each</small><div class="qty"><button data-minus="${i}">−</button>${x.quantity}<button data-plus="${i}">+</button><button class="remove" data-remove="${i}">REMOVE</button></div></div><b>${money(p.price*x.quantity)}</b></div>`}).join(""):'<p class="hint">Your bag is empty. Find your fit in the collection.</p>';
 const t=totals();$("#subtotal").textContent=money(t.subtotal);$("#shipping").textContent=t.shipping?money(t.shipping):"FREE";$("#total").textContent=money(t.total);
 document.querySelectorAll("[data-minus]").forEach(b=>b.onclick=()=>{let x=cart[+b.dataset.minus];x.quantity--;if(!x.quantity)cart.splice(+b.dataset.minus,1);renderCart()});
 document.querySelectorAll("[data-plus]").forEach(b=>b.onclick=()=>{cart[+b.dataset.plus].quantity++;renderCart()});
 document.querySelectorAll("[data-remove]").forEach(b=>b.onclick=()=>{cart.splice(+b.dataset.remove,1);renderCart()});
}
function toast(msg){$("#toast").textContent=msg;$("#toast").classList.remove("hidden");setTimeout(()=>$("#toast").classList.add("hidden"),2600)}
$("#openCart").onclick=()=>$("#cartOverlay").classList.remove("hidden");
$("#closeCart").onclick=()=>$("#cartOverlay").classList.add("hidden");
$("#checkoutBtn").onclick=()=>{if(!cart.length){toast("Your bag is empty.");return}$("#cartOverlay").classList.add("hidden");$("#checkoutOverlay").classList.remove("hidden");};
$("#closeCheckout").onclick=()=>$("#checkoutOverlay").classList.add("hidden");
async function post(url,body){const r=await fetch(url,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify(body)});const data=await r.json();if(!r.ok)throw new Error(data.error||"Request failed.");return data}
$("#checkoutForm").onsubmit=async e=>{
 e.preventDefault();if(!cart.length)return;
 const form=new FormData(e.target),customer=Object.fromEntries(form.entries()),payment=form.get("payment");
 const btn=$("#placeOrder"),err=$("#checkoutError");err.textContent="";btn.disabled=true;btn.textContent="PLEASE WAIT...";
 try{
  if(payment==="cod"){
   const result=await post("/api/orders/cod",{items:cart,customer});
   cart=[];renderCart();e.target.reset();$("#checkoutOverlay").classList.add("hidden");toast("Order received! Your order ID: "+result.orderId);
  }else{
   if(!config.onlinePaymentsEnabled)throw new Error("Online payment is not activated yet. Please choose Cash on Delivery, or contact TRYZONE to finish Razorpay setup.");
   const order=await post("/api/payments/create-order",{items:cart,customer});
   const rzp=new Razorpay({key:order.keyId,amount:order.amount,currency:order.currency,name:"TRYZONE",description:"Streetwear order",order_id:order.orderId,handler:async response=>{
    try{const verified=await post("/api/payments/verify",response);cart=[];renderCart();e.target.reset();$("#checkoutOverlay").classList.add("hidden");toast("Payment successful! Order "+verified.orderId)}catch(error){err.textContent=error.message}
   },modal:{ondismiss:()=>{btn.disabled=false;btn.textContent="PLACE ORDER"}}});
   rzp.on("payment.failed",response=>{err.textContent=response.error.description||"Payment failed."});rzp.open();
  }
 }catch(error){err.textContent=error.message}
 finally{btn.disabled=false;btn.textContent="PLACE ORDER"}
};
init();renderCart();
