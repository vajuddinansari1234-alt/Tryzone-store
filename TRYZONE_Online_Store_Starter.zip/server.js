require("dotenv").config();
const express = require("express");
const Razorpay = require("razorpay");
const crypto = require("crypto");
const path = require("path");

const app = express();
app.use(express.json({limit:"1mb"}));
app.use(express.static(path.join(__dirname, "public")));

const products = [
  {id:"tee-classic",name:"TRYZONE Classic Logo Tee",category:"T-Shirts",price:799,stock:30,sizes:["S","M","L","XL","XXL"],description:"Everyday streetwear essential."},
  {id:"tee-oversized",name:"TRYZONE Oversized Graphic Tee",category:"T-Shirts",price:999,stock:25,sizes:["S","M","L","XL","XXL"],description:"Relaxed fit with a bold graphic."},
  {id:"hoodie-essential",name:"TRYZONE Essential Hoodie",category:"Hoodies",price:1799,stock:15,sizes:["S","M","L","XL","XXL"],description:"A comfortable layer for every day."},
  {id:"cargo-black",name:"TRYZONE Cargo Pants",category:"Bottoms",price:1499,stock:18,sizes:["28","30","32","34","36"],description:"Utility-inspired street fit."}
];
const orders = new Map(); // Replace with a persistent database before production.
const razorpayReady = !!(process.env.RAZORPAY_KEY_ID && process.env.RAZORPAY_KEY_SECRET &&
  !process.env.RAZORPAY_KEY_ID.includes("replace") && !process.env.RAZORPAY_KEY_SECRET.includes("replace"));
const razorpay = razorpayReady ? new Razorpay({
  key_id: process.env.RAZORPAY_KEY_ID,
  key_secret: process.env.RAZORPAY_KEY_SECRET
}) : null;

app.get("/api/products", (_req,res)=>res.json(products));
app.get("/api/config", (_req,res)=>res.json({
  brand:"TRYZONE",
  currency:"INR",
  onlinePaymentsEnabled:razorpayReady,
  cashOnDeliveryEnabled:true,
  shippingFreeAbove:999,
  shippingFee:79
}));

function validateCart(items) {
  if (!Array.isArray(items) || !items.length || items.length > 30) throw new Error("Cart is empty or invalid.");
  let lines = [], subtotal = 0;
  for (const item of items) {
    const p = products.find(x=>x.id===item.productId);
    const qty = Number(item.quantity);
    if (!p || !Number.isInteger(qty) || qty<1 || qty>10) throw new Error("Invalid product or quantity.");
    if (!p.sizes.includes(String(item.size))) throw new Error("Invalid size for " + p.name);
    if (qty > p.stock) throw new Error("Not enough stock for " + p.name);
    subtotal += p.price*qty;
    lines.push({productId:p.id,name:p.name,price:p.price,quantity:qty,size:String(item.size)});
  }
  const shipping = subtotal >= 999 ? 0 : 79;
  return {lines,subtotal,shipping,total:subtotal+shipping};
}
function validateCustomer(c) {
  if (!c || !c.name || !c.phone || !c.address || !c.city || !c.pincode) throw new Error("Please complete all delivery details.");
  if (!/^[6-9]\d{9}$/.test(String(c.phone).replace(/\D/g,""))) throw new Error("Enter a valid 10-digit Indian mobile number.");
  if (!/^\d{6}$/.test(String(c.pincode))) throw new Error("Enter a valid 6-digit PIN code.");
  return {name:String(c.name).trim(),phone:String(c.phone).replace(/\D/g,""),email:String(c.email||"").trim(),address:String(c.address).trim(),city:String(c.city).trim(),state:String(c.state||"").trim(),pincode:String(c.pincode)};
}
app.post("/api/orders/cod", (req,res)=>{
  try {
    const cart=validateCart(req.body.items), customer=validateCustomer(req.body.customer);
    const id="TZ"+Date.now().toString().slice(-9);
    orders.set(id,{id,...cart,customer,paymentMethod:"COD",paymentStatus:"Pay on delivery",status:"Order received",createdAt:new Date().toISOString()});
    res.status(201).json({ok:true,orderId:id,message:"Order received. Pay cash when your order is delivered."});
  } catch(e) {res.status(400).json({error:e.message});}
});
app.post("/api/payments/create-order", async (req,res)=>{
  try {
    if (!razorpay) return res.status(503).json({error:"Online payments are not configured yet. Please use Cash on Delivery."});
    const cart=validateCart(req.body.items), customer=validateCustomer(req.body.customer);
    const receipt="tz_"+Date.now();
    const rpOrder=await razorpay.orders.create({amount:cart.total*100,currency:"INR",receipt,notes:{customer_name:customer.name,customer_phone:customer.phone}});
    orders.set(rpOrder.id,{id:rpOrder.id,...cart,customer,paymentMethod:"Razorpay",paymentStatus:"Pending",status:"Payment pending",createdAt:new Date().toISOString()});
    res.json({keyId:process.env.RAZORPAY_KEY_ID,orderId:rpOrder.id,amount:rpOrder.amount,currency:rpOrder.currency,brand:"TRYZONE"});
  } catch(e) {res.status(400).json({error:e.message||"Could not create payment order."});}
});
app.post("/api/payments/verify", (req,res)=>{
  try {
    const {razorpay_order_id,razorpay_payment_id,razorpay_signature}=req.body;
    const order=orders.get(razorpay_order_id);
    if (!order) return res.status(404).json({error:"Order not found."});
    const expected=crypto.createHmac("sha256",process.env.RAZORPAY_KEY_SECRET)
      .update(razorpay_order_id+"|"+razorpay_payment_id).digest("hex");
    const a=Buffer.from(expected), b=Buffer.from(String(razorpay_signature||""));
    if (a.length!==b.length || !crypto.timingSafeEqual(a,b)) return res.status(400).json({error:"Payment signature verification failed."});
    order.paymentStatus="Paid"; order.status="Payment confirmed"; order.paymentId=razorpay_payment_id;
    res.json({ok:true,orderId:order.id,message:"Payment successful. Thank you for shopping TRYZONE."});
  } catch(e) {res.status(400).json({error:"Could not verify payment."});}
});
app.get("/api/admin/orders", (req,res)=>{
  const token=process.env.ADMIN_TOKEN;
  if (!token || req.headers.authorization !== "Bearer "+token) return res.status(401).json({error:"Admin access not configured."});
  res.json([...orders.values()]);
});
app.get("*", (_req,res)=>res.sendFile(path.join(__dirname,"public","index.html")));
const port=process.env.PORT||3000;
app.listen(port,()=>console.log("TRYZONE store running on port "+port));
